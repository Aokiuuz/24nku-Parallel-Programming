Place the optional fallback training subset at data/Rockyou-1m.txt.
