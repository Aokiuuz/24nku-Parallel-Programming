# AUP Lab5 基础要求数据运行指南

## 1. 本次运行目标

基础要求是在 AMD AUP Learning Cloud 的 **HIP Programming Course** 环境中依次完成 6 个 Notebook，并记录报告中无法由静态分析得到的设备参数和实测数据。需要运行的 Notebook 为：

1. `Lab1_vadd.ipynb`：向量加法、block size、带宽、wavefront 与 occupancy。
2. `Lab2_Transpose.ipynb`：矩阵转置的 4 组规模计时。
3. `Lab3_Histogram.ipynb`：CPU、naive GPU、optimized GPU 的计时和加速比。
4. `Lab4_Reduction.ipynb`：不同 block size 的 occupancy、计时和 4 种归约策略。
5. `Lab5_MonteCarlo.ipynb`：不同 sample count 的计时和数值正确性。
6. `Lab6_KMeans.ipynb`：测试 4 的执行时间和正确性。

Notebook 中已经给出的公式和分析答案见 `report/exercise.md`。本次只填写真实设备信息、运行时间、带宽、误差条、正确性和由实测时间计算的加速比。

## 2. 启动 AUP GPU 服务器

打开课程提供的 AUP 链接并使用 GitHub 账户登录。进入 `Launch Your Server` 页面后按下列配置选择：

- Resource：`Community Materials -> HIP Programming Course`
- GPU Node：`AMD Radeon 8060S (Strix Halo iGPU)`
- 页面标称架构：RDNA 3.5，`gfx1151`
- 页面标称资源：40 Compute Units，64 GB LPDDR5X
- Runtime：首次建议填写 `90` 分钟

确认后点击 `Launch Server`。如果排队，保持页面打开，等待 JupyterLab 自动进入。不要同时启动多个服务器。

当前账户截图显示 1720 quota，8060S 每 20 分钟消耗 60 quota，即约 3 quota/分钟。90 分钟约消耗 270 quota。若只想先跑基础部分，可分成两次：

- 第一次 60 分钟：环境信息、Lab1-Lab3。
- 第二次 60 分钟：Lab4-Lab6。

服务器到期会终止计算。每完成一个 Notebook，立即保存并下载关键输出，不要等到最后统一保存。

## 3. 进入环境后的首次检查

进入 JupyterLab 后，打开 `File -> New -> Terminal`。执行：

```bash
mkdir -p ~/my_work/results
date | tee ~/my_work/results/run_info.txt
hostname | tee -a ~/my_work/results/run_info.txt
hipcc --version | tee -a ~/my_work/results/run_info.txt
rocminfo | tee ~/my_work/results/rocminfo.txt
rocm-smi | tee ~/my_work/results/rocm_smi.txt
```

再执行精简检查：

```bash
rocminfo | grep -E "Name:|Marketing Name:|Compute Unit|Wavefront Size|Max Waves Per CU|Max Queue Number|Max Size|LDS Size" | tee ~/my_work/results/gpu_summary.txt
```

确认以下条件：

- `hipcc --version` 正常输出。
- `rocminfo` 能看到 `gfx1151` 或 Radeon 8060S GPU agent。
- `rocm-smi` 能识别 GPU。

页面标称 40 个 Compute Units。报告中所有 GPU 参数均以本次 `rocminfo.txt` 为准。现有 `exercise.md` 题面中的“20 CUs”与当前平台页面不一致，不能直接抄入最终报告。

若 `hipcc: command not found`，先确认启动的是 `HIP Programming Course`，不是普通 Tutorial 或 CPU 资源。若选错，停止服务器并重新选择课程资源。

## 4. Notebook 的统一运行方法

左侧文件浏览器中找到 HIP Programming Course 的 6 个 Lab 目录。每个 Notebook 均按以下顺序操作：

1. 双击打开 `.ipynb`。
2. 确认右上角 Kernel 为课程默认 Python kernel。
3. 选择 `Kernel -> Restart Kernel and Run All Cells`。
4. 遇到确认提示选择 Restart/Run。
5. 从上到下观察输出；红色 traceback 出现后停止，不要继续记录后续数据。
6. 完成后选择 `File -> Save Notebook`。
7. 选择 `File -> Save and Export Notebook As -> HTML`，下载 HTML；若菜单无此项，至少下载 `.ipynb`。

计时数据必须来自同一次完整、无报错运行。不要在第一次 GPU 初始化的单次时间和多次重复实验的均值之间混用。Notebook 若给出 mean/std 或误差条，报告采用多次实验均值，并同时保存标准差。

运行期间不要打开其他 GPU 任务。若某次数据明显异常，可重启 kernel 后完整重跑该 Notebook，并保留稳定重复结果。

## 5. Lab1 Vector Addition

打开 `Lab1_Vector_Addition/Lab1_vadd.ipynb`，执行全部单元格。记录：

- Device Name
- Compute Units
- Wavefront Size
- Max Threads per Block
- Max Shared Memory per Block
- Max Wavefronts per CU
- block size 为 8、16、32、64、128、256、512、1024 时的 mean time 和标准差
- 每种 block size 的 memory bandwidth
- 最低 mean time 对应的 block size
- 最高 bandwidth 对应的 block size

将输出复制到：

```text
~/my_work/results/lab1_notes.txt
```

可在 Terminal 中用 `nano ~/my_work/results/lab1_notes.txt` 手工粘贴，也可以直接保留 Notebook HTML。

报告需要重点填写 `report/exercise.md` 中 Lab1 Exercise 1、4、6、7 的空项。occupancy 计算使用实际 `rocminfo` 的 wavefront/CU 上限，不使用题面中的固定 CU 数。

## 6. Lab2 Matrix Transpose

打开 `Lab2_Matrix_Transpose/Lab2_Transpose.ipynb`，执行全部单元格。记录 4 组测试的 GPU 执行时间：

| Test | Dimensions | Elements |
|---|---:|---:|
| 1 | 16 x 16 | 256 |
| 2 | 128 x 32 | 4,096 |
| 3 | 1 x 1024 | 1,024 |
| 4 | 1001 x 2001 | 2,003,001 |

同时记录每组 correctness/verification 是否通过。若 Notebook 同时输出 naive transpose 和 tiled transpose，分别记录两者，不能只保留较快值。

报告填写 Lab2 Exercise 3，并依据实测比例回答“大测试是否约慢 500 倍”。

## 7. Lab3 Histogram

打开 `Lab3_Histogram/Lab3_Histogram.ipynb`，执行全部单元格。该 Notebook 的程序在标准错误流输出 `KERNEL_MS`，计时排除了文件输入输出、GPU 初始化和结果打印。报告应采用该 kernel 时间。

记录：

- Serial CPU：testcase 2、testcase 4 的 mean time/std。
- Naive GPU：testcase 2、testcase 4 的 mean time/std。
- Optimized GPU：testcase 2、testcase 4 的 mean time/std。
- `Optimized vs Serial = Serial / Optimized GPU`。
- `Optimized vs Naive = Naive GPU / Optimized GPU`。
- uniform、Gaussian、highly skewed 分布实验的时间和误差条。
- 所有 correctness 检查结果。

如果 testcase 4 首次生成耗时较长，等待生成完成，不要重复点击运行。若内存不足，先关闭其他 Notebook kernel，再重新运行 Lab3。

## 8. Lab4 Reduction

打开 `Lab4_Reduction/Lab4_Reduction.ipynb`，执行全部单元格。记录：

- block size 64、128、256、512、1024 的 warps/block、occupancy 和 execution time。
- `exe_benchmark` 中四种策略的时间和结果：Naive Atomic、Tree Shared Memory、Tree + Warp Shuffle、Multi-Element + Tree + Shuffle。
- benchmark 给出的 speedup。
- 测试 2 和测试 3的 correctness。

注意 RDNA GPU 的 kernel 可能采用 wave32 或 wave64。代码与分析应使用 HIP 内建 `warpSize` 的实际值，不能在报告中无条件写死 32。

## 9. Lab5 Monte Carlo Integration

打开 `Lab5_Monte_Carlo_Integration/Lab5_MonteCarlo.ipynb`，执行全部单元格。记录：

- Test 1 的 8 个 y 值、求和、程序结果和手算结果。
- Test 4：100,000 samples 的 execution time。
- Test 7：10,000,000 samples 的 execution time。
- Test 8：100,000,000 samples 的 execution time。
- test 4 到 test 7 的样本数放大倍数、时间放大倍数。
- 数值误差或 correctness 输出。

大样本生成和运行需要时间。若服务器剩余时间不足 15 分钟，先保存已完成结果，再续开服务器运行 test 8。

## 10. Lab6 K-Means Clustering

打开 `Lab6_K-Means_Clustering/Lab6_KMeans.ipynb`，执行全部单元格。记录 Test 4：

- Sample size：50,000
- Clusters：50
- Max iterations：100
- Execution time
- 实际迭代次数（若输出）
- correctness/verification 状态
- 最终 centroid 或误差摘要（若输出）

报告填写 Lab6 Exercise 2。若程序提前收敛，应记录实际迭代次数，因为它会直接影响执行时间。

## 11. 数据记录表

建议在 `~/my_work/results/basic_results.md` 中使用以下模板：

```markdown
# Environment
- Date:
- Device Name:
- GPU architecture:
- Compute Units:
- Wavefront Size:
- Max Threads per Block:
- Max Shared Memory per Block:
- Max Wavefronts per CU:
- HIP/ROCm version:

# Lab1
- Best block size:
- Best mean time (ms):
- Best bandwidth (GB/s):
- BS8/16/32/64/128/256/512/1024 mean +/- std:
- Correctness:

# Lab2
- Test1/2/3/4 time (ms):
- Correctness:

# Lab3
- testcase2 CPU/naive/optimized (ms):
- testcase4 CPU/naive/optimized (ms):
- optimized vs CPU:
- optimized vs naive:
- Correctness:

# Lab4
- BS64/128/256/512/1024 occupancy and time:
- four-strategy benchmark times:
- Correctness:

# Lab5
- Test1 sum/result:
- Test4/Test7/Test8 time:
- Correctness/error:

# Lab6
- Test4 time:
- Actual iterations:
- Correctness:
```

## 12. 下载和备份

所有 Lab 完成后，在 Terminal 执行：

```bash
cd ~/my_work
tar -czf HIP_completed.tar.gz HIP results
ls -lh HIP_completed.tar.gz
```

在 JupyterLab 左侧文件浏览器中找到 `~/my_work/HIP_completed.tar.gz`，右键选择 Download。还应逐个下载 6 个已运行 Notebook 的 `.ipynb` 或导出的 HTML。最终本地至少保留：

- `HIP_completed.tar.gz`
- 6 个包含完整输出的 Notebook 或 HTML
- 关键图表截图
- AUP 启动页面截图

确认下载完成后再停止服务器。返回 AUP Home，点击 Stop Server 或结束当前 session，避免继续消耗 quota。

## 13. 常见错误处理

### Kernel 启动失败或找不到 GPU

先在 Terminal 执行：

```bash
rocminfo | grep -E "Marketing Name|Name:.*gfx"
```

没有 GPU agent 时，通常是资源选择错误或服务器异常。保存文件后停止实例并重新选择 8060S。

### `hipcc` 编译报 architecture 错误

当前节点是 `gfx1151`。优先使用 Notebook 原命令；若 Makefile 写死其他架构，执行：

```bash
make clean
make GPU_ARCH=gfx1151
```

### Notebook 一直显示 `[*]`

先查看 Terminal 中 `rocm-smi` 是否正常。大测试生成和执行可能持续数分钟；GPU 利用率为 0 且长时间无输出时，选择 `Kernel -> Interrupt Kernel`，检查前一个单元格错误后再重跑。

### 数据波动大

关闭其他 Notebook kernel，等待 10 秒后重跑多次计时单元格。报告采用均值和标准差，并注明重复次数。不要只挑最快一次。

### 服务器即将到期

立即保存 Notebook，并先打包下载 `~/my_work/HIP` 和 `~/my_work/results`。下次启动同一课程环境后检查文件是否仍在；即使平台持久化 home 目录，也应保留本地下载副本。

## 14. 完成判定

满足以下条件后，基础要求数据采集完成：

- 设备信息来自当前 8060S 实例的 `rocminfo`，参数无臆测。
- 6 个 Notebook 均从头到尾无报错运行。
- 每个需要实测的 Exercise 空项都有数据。
- 时间值明确单位和统计方式。
- CPU/GPU 或不同 GPU 实现的时间口径一致。
- 所有 correctness/verification 均通过，或保留了可定位的失败输出。
- 结果压缩包、Notebook 输出和截图已经下载到本地。
